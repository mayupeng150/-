package com.ambow.grade_student_oneToMany.service;

import java.lang.management.GarbageCollectorMXBean;
import java.util.List;

import com.ambow.grade_student_oneToMany.dao.GradeDao;
import com.ambow.grade_student_oneToMany.model.Grade;

public class GradeService {
	
	//����Dao��
	GradeDao gradeDao =new GradeDao();

	public List<Grade> findAllGrade() {
		// TODO Auto-generated method stub
		return gradeDao.findAllGrade();
	}

	public int delGrade(int id) {
		// TODO Auto-generated method stub
		return gradeDao.delGrade(id);
	}

	public Grade findGradeById(int id) {
		// TODO Auto-generated method stub
		return gradeDao.findGradeById(id);
	}

	public int updateGrade(Grade grade) {
		// TODO Auto-generated method stub
		return gradeDao.updateGrade(grade);
	}

}
