package com.ambow.grade_student_oneToMany.service;
import java.util.List;
import com.ambow.grade_student_oneToMany.dao.StudentDao;
import com.ambow.grade_student_oneToMany.model.Student;
import com.ambow.grade_student_oneToMany.servlet.page.PageBean;

public class StudentService {

	StudentDao studentDao=new StudentDao();
	
	public List<Student> findAllStudent() {
		// TODO Auto-generated method stub
		return studentDao.findAllStudent();
	}

	public int addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDao.addStudent(student);
	}

	public int updateStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDao.updateStudent(student);
	}

	public Student findStudentById(int id) {
		// TODO Auto-generated method stub
		return studentDao.findStudentById(id);
	}

	public int delStudent(int id) {
		// TODO Auto-generated method stub
		return studentDao.delStudent(id);
	}

	public PageBean findAllUserByPage(int page){
		
		/*
		 * 
		 *  private int page;	// 当前页数
			private int totalCount; // 总记录数
			private int totalPage; // 总页数
			private int limit;	// 每页显示的记录数
			private List<T> list; // 每页显示数据的集合.
		 */
		
		StudentDao studentDao=new StudentDao();
		PageBean<Student> pb=new PageBean<Student>();
		//设置当前页数
		pb.setPage(page);
		//设置每页显示几条数据
		
		int limit=5;//每页显示5条
		pb.setLimit(limit);
		
		//得出总条数
		int totalCount=studentDao.findCountUser();
		//设置总条数
		pb.setTotalCount(totalCount);
		
		//int totalPage=Math.ceil(totalCount / limit);
		//定义总页数
		//int totalPage=0;
		
		int totalPage=0;
		if(totalCount%limit==0){
			totalPage=totalCount/limit;		
		}else{	
			totalPage=(totalCount/limit)+1;
		}
		
		//设置总页数
		pb.setTotalPage(totalPage);
		
		
		//得出limit开始的第一个参数
		int begin=(page-1)*limit;
		
		pb.setList(studentDao.finaAllUserByPage(begin, limit));
		
		return pb;
			
	}


	public List<Student> findAllUserByPageOnJson(int page, int limit) {
		// TODO Auto-generated method stub
		
		StudentDao userDao=new StudentDao();
		
		return userDao.findAllUserByPageJson(page,limit);
	}
}
