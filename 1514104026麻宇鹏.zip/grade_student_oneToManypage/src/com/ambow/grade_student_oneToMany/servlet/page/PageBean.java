package com.ambow.grade_student_oneToMany.servlet.page;



import java.util.List;

/**
 * 分页类的封装
 * @author 传智.郭嘉
 * 
 * 把我们所有的分页的信息封装起来的一个类   
 *
 */
public class PageBean<T> {
	

	private int page;	// 当前页数
	private int totalCount; // 总记录数
	private int totalPage; // 总页数
	private int limit;	// 每页显示的记录数
	
	/*
	 * 总页数=总记录数/每页显示个数
	 * 
	 * 一页显示5条  如果25条    5页 5
	 * 			如果26条     6页  5+1
	 * 			如果23条     5页  4+1
	 * 
	 * 
	 * 
	 * if(totalcount%==0){
	 * 
	 * totalPage=totalcount/limit;
	 * }else{
	 * totalPage=totalcount/limit+1;
	 * 
	 * }
	 * 
	 * 
	 */
	
	
	private List<T> list; // 每页显示数据的集合.
	
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getLimit() {
		return limit;
	}
	
	public void setLimit(int limit) {
		this.limit = limit;
	}
	
	public List<T> getList() {
		return list;
	}
	public void setList(List<T> list) {
		this.list = list;
	}
	
}
