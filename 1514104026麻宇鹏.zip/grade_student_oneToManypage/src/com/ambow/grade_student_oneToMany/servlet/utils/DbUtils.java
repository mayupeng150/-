package com.ambow.grade_student_oneToMany.servlet.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;



public class DbUtils {
	
	
	private static String driverClass;
	
	private static String url;
	private static String username;
	private static String password;
	
	//д��ȡ�ļ��е�����
	
	static{
		
		
		
		ResourceBundle bundle = ResourceBundle.getBundle("dbinfo");
		
		driverClass = bundle.getString("driverClass");
		url = bundle.getString("url");
		username = bundle.getString("username");
		password  =bundle.getString("password");
		
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	

	//Ӧ������������
	public static Connection getConnection() throws SQLException{
		
		return DriverManager.getConnection(url,username,password);
	}
	
	//�ر���������
	public static void closeAll(ResultSet rs,Statement stmt,Connection conn){
		
		if(rs!=null){
			
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn!=null){
			
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
		
		
		
	}
	
	

}
