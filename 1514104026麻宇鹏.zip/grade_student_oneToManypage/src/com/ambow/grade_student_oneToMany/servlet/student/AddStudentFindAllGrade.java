package com.ambow.grade_student_oneToMany.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ambow.grade_student_oneToMany.model.Grade;
import com.ambow.grade_student_oneToMany.service.GradeService;

public class AddStudentFindAllGrade extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		GradeService gradeService=new GradeService();
		List<Grade> list=gradeService.findAllGrade();
		
		request.setAttribute("list", list);
		
		request.getRequestDispatcher("/student/addStudent.jsp").forward(request, response);
		
		
	}

}
