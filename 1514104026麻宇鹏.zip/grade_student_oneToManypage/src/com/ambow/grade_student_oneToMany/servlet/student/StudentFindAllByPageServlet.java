package com.ambow.grade_student_oneToMany.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ambow.grade_student_oneToMany.service.StudentService;
import com.ambow.grade_student_oneToMany.servlet.page.PageBean;
public class StudentFindAllByPageServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		
		String page = request.getParameter("page");
		
		StudentService studentService=new StudentService();
		PageBean pageBean = studentService.findAllUserByPage(Integer.parseInt(page));
		System.out.println(page);
		HttpSession session=request.getSession();
		session.setAttribute("pageBean", pageBean);
		
		//${pageBean.list}
		if(pageBean!=null){
			request.getRequestDispatcher("/student/listStudent.jsp").forward(request, response);
		}

	}


}
