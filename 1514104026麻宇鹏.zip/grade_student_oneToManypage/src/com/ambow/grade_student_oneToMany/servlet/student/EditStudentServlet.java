package com.ambow.grade_student_oneToMany.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ambow.grade_student_oneToMany.model.Grade;
import com.ambow.grade_student_oneToMany.model.Student;
import com.ambow.grade_student_oneToMany.service.GradeService;
import com.ambow.grade_student_oneToMany.service.StudentService;

public class EditStudentServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		String stuId = request.getParameter("id");
		
		StudentService studentService =new StudentService();
		Student student = studentService.findStudentById(Integer.parseInt(stuId));
		
		GradeService gradeService=new GradeService();
		List<Grade> list = gradeService.findAllGrade();
		
		if((list!=null)&&(student!=null)){
			
			
			request.setAttribute("list", list);
			request.setAttribute("student", student);
			
			request.getRequestDispatcher("/student/editStudent.jsp").forward(request, response);
			
			
			
			
		}
		
		
	}

}
