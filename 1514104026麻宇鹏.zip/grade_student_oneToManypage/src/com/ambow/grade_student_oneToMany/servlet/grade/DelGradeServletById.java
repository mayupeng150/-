package com.ambow.grade_student_oneToMany.servlet.grade;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ambow.grade_student_oneToMany.service.GradeService;

public class DelGradeServletById extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
	
		String id = request.getParameter("id");
		
		
		GradeService gradeService =new GradeService();
		int row = gradeService.delGrade(Integer.parseInt(id));
		
		if(row >0){
			
			request.getRequestDispatcher("findAllGradeServlet").forward(request, response);
			
			
		}
		
		
	}

}
