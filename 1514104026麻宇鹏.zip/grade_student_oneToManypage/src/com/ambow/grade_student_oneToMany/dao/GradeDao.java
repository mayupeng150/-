package com.ambow.grade_student_oneToMany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ambow.grade_student_oneToMany.model.Grade;
import com.ambow.grade_student_oneToMany.servlet.utils.DbUtils;


public class GradeDao {
	
	
	Connection  conn =null;
	PreparedStatement pstmt=null;
	Statement stmt =null;
	ResultSet rs=null;
	
	

	public List<Grade> findAllGrade() {
		// TODO Auto-generated method stub
		
		
		List<Grade> list =new ArrayList<Grade>();
		try {
			conn =DbUtils.getConnection();
			
			String sql ="select * from grade";
			
			stmt = conn.createStatement();
			
			rs =stmt.executeQuery(sql);
			
			while(rs.next()){
				
				Grade grade =new Grade();
				grade.setId(rs.getInt("id"));
				grade.setGradeName(rs.getString("gradeName"));
				grade.setGradeDesc(rs.getString("gradeDesc"));
				
				
				list.add(grade);
				
			}
			
			
	
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(rs, stmt, conn);
		}
		
		
		
		
		
		return list;
	}



	public int delGrade(int id) {
		// TODO Auto-generated method stub
		int row =0;
		
		try {
			conn = DbUtils.getConnection();
			
			String sql ="delete from grade where id=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			row = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(null, pstmt, conn);
		}
		return row;
	}



	public Grade findGradeById(int id) {
		
		Grade grade =null;
		
		try {
			// TODO Auto-generated method stub
			
			conn = DbUtils.getConnection();
			
			String sql ="select * from grade where id =?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1,id);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				
				grade=new Grade();
				grade.setId(rs.getInt("id"));
				grade.setGradeName(rs.getString("gradeName"));
				
				grade.setGradeDesc(rs.getString("gradeDesc"));
				
				
				
				
			}
			
			
			
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		
		DbUtils.closeAll(rs, pstmt, conn);
	}
	
	return grade;
	}



	public int updateGrade(Grade grade) {
		// TODO Auto-generated method stub
		
		int row =0;
		try {
			conn =DbUtils.getConnection();
			String sql ="update grade set gradeName =?,gradeDesc=? where id =?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, grade.getGradeName());			
			pstmt.setString(2, grade.getGradeDesc());			
			pstmt.setInt(3, grade.getId());		
			
			 row = pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(null, pstmt, conn);
		}
		
		
		
		return row;
	}
}
