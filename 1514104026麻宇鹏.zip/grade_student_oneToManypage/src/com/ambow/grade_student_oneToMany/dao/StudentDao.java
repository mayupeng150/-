package com.ambow.grade_student_oneToMany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.ambow.grade_student_oneToMany.model.Student;
import com.ambow.grade_student_oneToMany.servlet.utils.DbUtils;



public class StudentDao {

	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	Statement stmt=null;
	GradeDao gradeDao=new GradeDao();
	
	public List<Student> findAllStudent() {
		
		GradeDao gradeDao=new GradeDao();
		
		List<Student> list=new ArrayList<Student>();
		try {
			conn=DbUtils.getConnection();
			
			String sql="select * from student";
			
			stmt=conn.createStatement();
			
			rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				Student student=new Student();
				
				student.setId(rs.getInt("id"));
				student.setAge(rs.getInt("age"));
				student.setStuNo(rs.getString("stuNo"));
				student.setStuName(rs.getString("stuName"));
				student.setSex(rs.getString("sex"));
				student.setGrade(gradeDao.findGradeById(rs.getInt("gradeId")));
				
				list.add(student);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtils.closeAll(rs, stmt, conn);
		}
	return list;
	}

	public int addStudent(Student student) {
		// TODO Auto-generated method stub
		
		int row=0;
		
		try {
			conn=DbUtils.getConnection();
			String sql="insert into student(stuNo,stuName,sex,age,gradeId) values(?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1, student.getStuNo());
			pstmt.setString(2, student.getStuName());
			pstmt.setString(3, student.getSex());
			pstmt.setInt(4, student.getAge());
			pstmt.setInt(5, student.getGrade().getId());
			
			row=pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtils.closeAll(null, pstmt, conn);
		}
		return row;
	}

	public int updateStudent(Student student) {
		// TODO Auto-generated method stub
		int row =0;
		try {
			conn=DbUtils.getConnection();
			
			String sql="update student set stuNo=?,stuName=?,sex=?,age=?,gradeId=? where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, student.getStuNo());
			pstmt.setString(2, student.getStuName());
			pstmt.setString(3, student.getSex());
			pstmt.setInt(4, student.getAge());
			pstmt.setInt(5, student.getGrade().getId());
			pstmt.setInt(6, student.getId());
			
			
			 row = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(rs, pstmt, conn);
		}
		
		
	
		//update t_Student set StudentName=?,StudentDesc=? where id=?
		return row;
	}

	public Student findStudentById(int id) {
		// TODO Auto-generated method stub
		Student student=null;
		try {
			conn=DbUtils.getConnection();
			
			String sql="select * from student where id=?";
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1, id);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()){
				
				 student=new Student();

					student.setId(rs.getInt("id"));
					student.setStuName(rs.getString("stuName"));
					student.setStuNo(rs.getString("stuNo"));
					student.setSex(rs.getString("sex"));
					student.setAge(rs.getInt("age"));
					student.setGrade(gradeDao.findGradeById(rs.getInt("gradeId")));
				
				
			}
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(rs, pstmt, conn);
		}
		
		
		//select * from t_Student where id=?
		return student;
	}

	public int delStudent(int id) {
		// TODO Auto-generated method stub
         int row =0;
		
		try {
			conn = DbUtils.getConnection();
			
			String sql ="delete from student where id=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			row = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			DbUtils.closeAll(null, pstmt, conn);
		}
		return row;
	}

	public  int findCountUser() {
		// TODO Auto-generated method stub
		int count = 0;
		try {
			// 1.获取连接
			conn = DbUtils.getConnection();
			// 2.编写sql语句
			String sql = "SELECT count(*) count from student";
			// 3.获取执行sql语句对象
			pstmt = conn.prepareStatement(sql);	
			rs = pstmt.executeQuery();
			// 6.处理结果集
			while (rs.next()) {
				count = rs.getInt("count");
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			// 6.释放资源
			DbUtils.closeAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<Student> finaAllUserByPage(int begin, int limit) {
		// TODO Auto-generated method stub
		List<Student> list = new ArrayList<Student>();
		try {
			// 1.获取连接
			conn = DbUtils.getConnection();
			// 2.编写sql语句
			String sql = "select * from student  LIMIT ?,?";
			// 3.获取执行sql语句对象

			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, begin);
			pstmt.setInt(2, limit);

			rs = pstmt.executeQuery();

			// 6.处理结果集
			while (rs.next()) {

				Student student=new Student();
				
				student.setId(rs.getInt("id"));
				student.setAge(rs.getInt("age"));
				student.setStuNo(rs.getString("stuNo"));
				student.setStuName(rs.getString("stuName"));
				student.setSex(rs.getString("sex"));
				student.setGrade(gradeDao.findGradeById(rs.getInt("gradeId")));
				
				list.add(student);

			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			// 6.释放资源
			DbUtils.closeAll(rs, pstmt, conn);
		}
		return list;

	}

	public List<Student> findAllUserByPageJson(int page, int limit) {
		// TODO Auto-generated method stub

		List<Student> list = new ArrayList<Student>();
		try {
			// 1.获取连接
			conn = DbUtils.getConnection();
			// 2.编写sql语句
			int begin=(page-1)*limit;
			String sql = "select * from user  LIMIT ?,?";
			// 3.获取执行sql语句对象

			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, begin);
			pstmt.setInt(2, limit);

			rs = pstmt.executeQuery();

			// 6.处理结果集
			while (rs.next()) {

				

				Student student=new Student();
				
				student.setId(rs.getInt("id"));
				student.setAge(rs.getInt("age"));
				student.setStuNo(rs.getString("stuNo"));
				student.setStuName(rs.getString("stuName"));
				student.setSex(rs.getString("sex"));
				student.setGrade(gradeDao.findGradeById(rs.getInt("gradeId")));
				
				list.add(student);

			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			// 6.释放资源
			DbUtils.closeAll(rs, pstmt, conn);
		}
		return list;


	}
}

