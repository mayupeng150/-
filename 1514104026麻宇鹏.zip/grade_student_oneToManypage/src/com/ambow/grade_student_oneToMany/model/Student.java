package com.ambow.grade_student_oneToMany.model;

public class Student {
	
	
	private int id;
	private String stuNo;
	private String stuName;
	private String sex;
	private int age;
	
	private Grade grade;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStuNo() {
		return stuNo;
	}

	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public Student(int id, String stuNo, String stuName, String sex, int age,
			Grade grade) {
		super();
		this.id = id;
		this.stuNo = stuNo;
		this.stuName = stuName;
		this.sex = sex;
		this.age = age;
		this.grade = grade;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", stuNo=" + stuNo + ", stuName="
				+ stuName + ", sex=" + sex + ", age=" + age + ", garde="
				+ grade + "]";
	}
	
	
	
	

}
