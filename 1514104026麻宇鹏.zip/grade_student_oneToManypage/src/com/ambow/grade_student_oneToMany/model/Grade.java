package com.ambow.grade_student_oneToMany.model;

import java.util.ArrayList;
import java.util.List;

public class Grade {
	
	
	private int id;
	private String gradeName;
	private String gradeDesc;
	
	private List<Student> listStu=new ArrayList<Student>();
	
	public List<Student> getListStu() {
		return listStu;
	}
	public void setListStu(List<Student> listStu) {
		this.listStu = listStu;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public String getGradeDesc() {
		return gradeDesc;
	}
	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}
	public Grade(int id, String gradeName, String gradeDesc,
			List<Student> listStu) {
		super();
		this.id = id;
		this.gradeName = gradeName;
		this.gradeDesc = gradeDesc;
		this.listStu = listStu;
	}
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Grade [id=" + id + ", gradeName=" + gradeName + ", gradeDesc="
				+ gradeDesc + ", listStu=" + listStu + "]";
	}
	
	
	
	
	

}
